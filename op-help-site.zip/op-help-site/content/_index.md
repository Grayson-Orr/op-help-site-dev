---
title: Home
---

Nau mai | welcome to the Bachelor of Information Technology help site.

Whether you are a new learner, or an existing one, and want to learn how to get started here at Te Kura Matatini ki Otago | Otago Polytechnic. Do not be worry if you are stuck or confused. That is what we are here for. To get started, simply use the **Navigation** feature on the left-hand side to find study-related information such as Student Hub, Learning Support, IT Support and much more.